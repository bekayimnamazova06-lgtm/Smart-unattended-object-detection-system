"""
Smart Unattended Object Detection System — app.py
==================================================
Streamlit web dashboard for live monitoring.

Features:
  - Live video feed with annotated detections
  - Real-time alert table (person count, bag statuses)
  - System log / event feed
  - Controls: start / stop, source selection, threshold sliders
  - Screenshot gallery

Run with:
    streamlit run app.py
"""

import time
import os
import glob
from pathlib import Path
from io import BytesIO
from datetime import datetime

import cv2
import streamlit as st
import numpy as np
from PIL import Image

from main import UnattendedObjectDetector, CONFIG
from utils import bgr_to_rgb, resize_frame

# ─── Page Configuration ───────────────────────────────────────────────────────
st.set_page_config(
    page_title="Smart Surveillance Dashboard",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── Custom CSS ───────────────────────────────────────────────────────────────
st.markdown("""
<style>
    /* Dark surveillance aesthetic */
    .stApp { background-color: #0d1117; color: #e6edf3; }

    .metric-card {
        background: #161b22;
        border: 1px solid #30363d;
        border-radius: 10px;
        padding: 16px;
        text-align: center;
    }
    .metric-value { font-size: 2.4rem; font-weight: 700; margin: 0; }
    .metric-label { font-size: 0.8rem; color: #8b949e; text-transform: uppercase;
                    letter-spacing: 0.08em; margin-top: 4px; }

    .status-safe     { color: #3fb950; }
    .status-warning  { color: #d29922; }
    .status-critical { color: #f85149; }

    .alert-row { padding: 6px 10px; border-radius: 6px; margin: 4px 0;
                 font-family: monospace; font-size: 0.85rem; }
    .alert-safe     { background: #0d2b1a; color: #3fb950; }
    .alert-warning  { background: #2b1f0d; color: #d29922; }
    .alert-critical { background: #2b0d0d; color: #f85149;
                      animation: blink 1s step-start infinite; }
    @keyframes blink { 50% { opacity: 0.5; } }

    div[data-testid="stSidebar"] { background: #0d1117; border-right: 1px solid #21262d; }
    h1, h2, h3 { color: #58a6ff; }
    .stButton>button { background: #238636; color: #fff; border: none; border-radius: 6px; }
    .stButton>button:hover { background: #2ea043; }
</style>
""", unsafe_allow_html=True)


# ─── Session State Initialisation ─────────────────────────────────────────────
def init_session():
    defaults = {
        "running": False,
        "detector": None,
        "event_log": [],        # list of (timestamp, message, level)
        "frame_stats": [],      # rolling stats history
        "latest_frame": None,   # numpy RGB array
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_session()


# ─── Helper: push to event log ────────────────────────────────────────────────
def log_event(msg: str, level: str = "info"):
    ts = datetime.now().strftime("%H:%M:%S")
    st.session_state.event_log.append((ts, msg, level))
    # Keep last 200 events
    if len(st.session_state.event_log) > 200:
        st.session_state.event_log = st.session_state.event_log[-200:]


# ─── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Configuration")
    st.divider()

    # Video source
    source_type = st.radio("Video Source", ["Webcam", "Video File"], horizontal=True)
    if source_type == "Webcam":
        cam_index = st.number_input("Camera Index", min_value=0, max_value=10, value=0, step=1)
        video_source = int(cam_index)
    else:
        video_path = st.text_input("Video File Path", placeholder="e.g. demo/airport.mp4")
        video_source = video_path if video_path else None

    st.divider()

    # Alert thresholds
    st.markdown("### 🚨 Alert Thresholds")
    warning_time = st.slider("Warning threshold (s)", 1, 30, CONFIG["warning_time"])
    critical_time = st.slider("Critical threshold (s)", 2, 60, CONFIG["critical_time"])
    owner_dist = st.slider("Owner away distance (px)", 50, 500, CONFIG["owner_away_distance"])
    confidence = st.slider("Detection confidence", 0.1, 0.9, CONFIG["confidence_threshold"], step=0.05)

    st.divider()

    # Display options
    st.markdown("### 🖥️ Display")
    show_log = st.checkbox("Show Event Log", value=True)
    show_gallery = st.checkbox("Show Screenshot Gallery", value=True)
    resize_width = st.slider("Preview width (px)", 400, 1280, 960, step=80)

    st.divider()
    st.markdown(
        "<div style='color:#8b949e;font-size:0.75rem;'>"
        "YOLOv8 + DeepSORT<br>"
        "AI & Prompt Engineering — Final Project"
        "</div>",
        unsafe_allow_html=True,
    )


# ─── Header ───────────────────────────────────────────────────────────────────
st.markdown("# 🔍 Smart Unattended Object Detection")
st.markdown(
    "<p style='color:#8b949e;margin-top:-12px;'>"
    "Real-time security monitoring · YOLOv8 + DeepSORT · Owner-linking · Alert system"
    "</p>",
    unsafe_allow_html=True,
)
st.divider()


# ─── Control Row ──────────────────────────────────────────────────────────────
col_start, col_stop, col_snap, col_status = st.columns([1, 1, 1, 3])

with col_start:
    start_clicked = st.button("▶ Start", use_container_width=True, type="primary")

with col_stop:
    stop_clicked = st.button("⏹ Stop", use_container_width=True)

with col_snap:
    snap_clicked = st.button("📸 Screenshot", use_container_width=True)

with col_status:
    status_placeholder = st.empty()

if start_clicked and not st.session_state.running:
    if source_type == "Video File" and not video_source:
        st.error("Please enter a valid video file path.")
    else:
        cfg = {**CONFIG,
               "warning_time": warning_time,
               "critical_time": critical_time,
               "owner_away_distance": owner_dist,
               "confidence_threshold": confidence}
        st.session_state.detector = UnattendedObjectDetector(cfg=cfg)
        st.session_state.running = True
        log_event("Detection started.", "info")
        status_placeholder.success("System running…")

if stop_clicked:
    st.session_state.running = False
    log_event("Detection stopped by user.", "info")
    status_placeholder.warning("System stopped.")

if not st.session_state.running:
    status_placeholder.info("System idle — press ▶ Start")


# ─── Main layout: video | metrics ─────────────────────────────────────────────
vid_col, metrics_col = st.columns([3, 1])

with vid_col:
    st.markdown("### 📹 Live Feed")
    frame_placeholder = st.empty()

with metrics_col:
    st.markdown("### 📊 Live Metrics")
    m_persons  = st.empty()
    m_bags     = st.empty()
    m_warning  = st.empty()
    m_critical = st.empty()

# Detected objects table
st.markdown("### 🗂️ Tracked Objects")
table_placeholder = st.empty()

# Alert log
if show_log:
    st.markdown("### 📋 Event Log")
    log_placeholder = st.empty()


# ─── Screenshot Gallery ───────────────────────────────────────────────────────
def render_gallery():
    shots = sorted(glob.glob("screenshots/*.jpg"), reverse=True)[:12]
    if not shots:
        st.info("No screenshots yet — they appear here when CRITICAL alerts trigger.")
        return
    cols = st.columns(4)
    for i, path in enumerate(shots):
        with cols[i % 4]:
            img = Image.open(path)
            st.image(img, caption=os.path.basename(path), use_container_width=True)


if show_gallery:
    with st.expander("📷 Screenshot Gallery", expanded=False):
        render_gallery()


# ─── Metric card HTML helper ──────────────────────────────────────────────────
def metric_card(label: str, value, css_class: str = "") -> str:
    val_html = f'<p class="metric-value {css_class}">{value}</p>'
    return (
        f'<div class="metric-card">'
        f'{val_html}'
        f'<p class="metric-label">{label}</p>'
        f'</div>'
    )


# ─── Main Detection Loop ──────────────────────────────────────────────────────
if st.session_state.running and st.session_state.detector is not None:
    detector: UnattendedObjectDetector = st.session_state.detector
    cap = cv2.VideoCapture(video_source)

    if not cap.isOpened():
        st.error(f"❌ Cannot open video source: {video_source}")
        st.session_state.running = False
    else:
        prev_statuses: dict = {}

        while st.session_state.running:
            ret, frame = cap.read()
            if not ret:
                log_event("End of video stream.", "info")
                st.session_state.running = False
                break

            # Resize for performance
            frame = resize_frame(frame, max_width=resize_width)

            # Process frame
            annotated, stats = detector.process_frame(frame)

            # Convert to RGB for Streamlit
            rgb = bgr_to_rgb(annotated)
            frame_placeholder.image(rgb, use_container_width=True)
            st.session_state.latest_frame = rgb

            # Manual screenshot
            if snap_clicked:
                from utils import capture_screenshot, bgr_to_rgb as _b2r
                ts = time.strftime("%Y%m%d_%H%M%S")
                capture_screenshot(annotated, f"screenshots/manual_{ts}.jpg")
                log_event(f"Manual screenshot saved: manual_{ts}.jpg", "info")

            # ── Update metric cards ──────────────────────────────────────
            m_persons.markdown(
                metric_card("Persons Tracked", stats["persons"]), unsafe_allow_html=True)
            m_bags.markdown(
                metric_card("Bags Tracked", stats["bags"]), unsafe_allow_html=True)
            m_warning.markdown(
                metric_card("Warnings", stats["warnings"], "status-warning"),
                unsafe_allow_html=True)
            m_critical.markdown(
                metric_card("Critical", stats["criticals"], "status-critical"),
                unsafe_allow_html=True)

            # ── Object table ─────────────────────────────────────────────
            if stats["objects"]:
                rows_html = ""
                for obj in stats["objects"]:
                    elapsed = (
                        int(time.time() - obj["unattended_since"])
                        if obj["unattended_since"]
                        else 0
                    )
                    css = f"alert-{obj['status']}"
                    icon = {"safe": "✅", "warning": "⚠️", "critical": "🚨"}.get(obj["status"], "")
                    owner_txt = f"Person #{obj['owner_id']}" if obj["owner_id"] else "Unlinked"
                    rows_html += (
                        f'<div class="alert-row {css}">'
                        f'{icon} <b>{obj["label"].capitalize()} #{obj["id"]}</b> &nbsp;|&nbsp; '
                        f'Status: <b>{obj["status"].upper()}</b> &nbsp;|&nbsp; '
                        f'Owner: {owner_txt} &nbsp;|&nbsp; '
                        f'Unattended: {elapsed}s'
                        f'</div>'
                    )
                table_placeholder.markdown(rows_html, unsafe_allow_html=True)
            else:
                table_placeholder.info("No bags/luggage detected.")

            # ── Auto-log status changes ───────────────────────────────────
            for obj in stats["objects"]:
                tid = obj["id"]
                new_status = obj["status"]
                if prev_statuses.get(tid) != new_status:
                    prev_statuses[tid] = new_status
                    if new_status == "warning":
                        log_event(
                            f"{obj['label'].capitalize()} #{tid} → WARNING (>5s unattended)",
                            "warning")
                    elif new_status == "critical":
                        log_event(
                            f"{obj['label'].capitalize()} #{tid} → CRITICAL ALERT (>10s unattended)!",
                            "critical")

            # ── Render event log ─────────────────────────────────────────
            if show_log:
                log_html = ""
                for ts, msg, lvl in reversed(st.session_state.event_log[-30:]):
                    css = {"info": "alert-safe", "warning": "alert-warning",
                           "critical": "alert-critical"}.get(lvl, "alert-safe")
                    log_html += f'<div class="alert-row {css}">[{ts}] {msg}</div>'
                log_placeholder.markdown(log_html, unsafe_allow_html=True)

            # Small sleep to prevent UI freezing
            time.sleep(0.01)

        cap.release()
        st.info("Detection finished. Press ▶ Start to begin again.")

elif not st.session_state.running:
    # Show placeholder when idle
    placeholder_img = np.zeros((360, 640, 3), dtype=np.uint8)
    cv2.putText(placeholder_img, "Press  Start  to begin", (120, 190),
                cv2.FONT_HERSHEY_SIMPLEX, 0.9, (80, 80, 80), 2)
    frame_placeholder.image(placeholder_img, channels="BGR", use_container_width=True)
    table_placeholder.info("System idle — no objects tracked.")


# ─── Footer ───────────────────────────────────────────────────────────────────
st.divider()
st.markdown(
    "<p style='text-align:center;color:#484f58;font-size:0.8rem;'>"
    "Smart Unattended Object Detection System · AI &amp; Prompt Engineering Final Project"
    "</p>",
    unsafe_allow_html=True,
)
