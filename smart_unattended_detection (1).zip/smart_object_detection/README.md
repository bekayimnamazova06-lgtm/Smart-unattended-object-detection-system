# 🔍 Smart Unattended Object Detection System

<div align="center">

![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?style=for-the-badge&logo=python&logoColor=white)
![YOLOv8](https://img.shields.io/badge/YOLOv8-Ultralytics-00FFFF?style=for-the-badge)
![DeepSORT](https://img.shields.io/badge/Tracking-DeepSORT-FF6B35?style=for-the-badge)
![Streamlit](https://img.shields.io/badge/UI-Streamlit-FF4B4B?style=for-the-badge&logo=streamlit&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)

**An intelligent real-time security system that detects unattended luggage, links objects to their owners, and issues graded alerts when objects are left behind.**

[Features](#-features) · [Architecture](#-architecture) · [Installation](#-installation) · [Usage](#-usage) · [Demo](#-demo) · [Future Work](#-future-improvements)

</div>

---

## 📌 Project Overview

Unattended baggage is one of the most critical security challenges in airports, train stations, shopping malls, and public spaces. Traditional CCTV relies entirely on human operators — prone to fatigue and attention lapses.

**Smart Unattended Object Detection System** automates this using computer vision:

1. **Detects** people and luggage in real time (YOLOv8)
2. **Tracks** each object across frames with a stable ID (DeepSORT)
3. **Links** every bag to its nearest owner automatically
4. **Monitors** the distance between bag and owner every frame
5. **Alerts** operators at two escalating thresholds (⚠ WARNING → 🚨 CRITICAL)
6. **Saves** screenshot evidence and plays an audible alarm

---

## ✨ Features

### Core
| Feature | Details |
|---|---|
| Object Detection | YOLOv8 (nano by default; swappable to small/medium) |
| Tracked classes | `person`, `backpack`, `handbag`, `suitcase` |
| Multi-object Tracking | DeepSORT with appearance re-identification |
| Persistent IDs | Each person and bag keeps a unique integer ID across frames |
| Owner Linking | Nearest-person algorithm on first detection |
| Distance Monitoring | Per-frame Euclidean distance owner ↔ bag |
| WARNING threshold | Bag unattended > **5 seconds** → orange alert |
| CRITICAL threshold | Bag unattended > **10 seconds** → red alert + alarm + screenshot |

### Advanced
| Feature | Details |
|---|---|
| 🔔 Alarm Sound | Non-blocking background thread; plays `assets/alarm.wav` |
| 📸 Auto Screenshots | JPEG saved to `screenshots/` on CRITICAL trigger |
| 🖥️ Streamlit Dashboard | Live video feed, metrics, object table, event log, gallery |
| 🎨 Visual Overlays | Colour-coded boxes, dashed owner-link lines, timer badges |
| 🔢 Configurable | All thresholds editable in `main.py → CONFIG` or via UI sliders |
| 📦 Modular Code | Clean separation: detection / tracking / utils / UI |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     Video Source                         │
│              (webcam / video file / RTSP)                │
└──────────────────────────┬──────────────────────────────┘
                           │ frames
                           ▼
┌─────────────────────────────────────────────────────────┐
│                      main.py                             │
│  ┌──────────────┐   ┌──────────────┐   ┌─────────────┐  │
│  │  YOLOv8      │   │  ObjectState │   │ Alert Logic │  │
│  │  Detection   │──▶│  Registry    │──▶│  (timer,    │  │
│  │  (ultralytics│   │  (bag→owner) │   │   distance) │  │
│  └──────────────┘   └──────────────┘   └─────────────┘  │
│          │                                      │         │
│          ▼                                      ▼         │
│  ┌──────────────┐                    ┌─────────────────┐ │
│  │  tracker.py  │                    │    utils.py     │ │
│  │  (DeepSORT)  │                    │  draw · alarm   │ │
│  │  stable IDs  │                    │  screenshot     │ │
│  └──────────────┘                    └─────────────────┘ │
└──────────────────────────┬──────────────────────────────┘
                           │ annotated frame + stats dict
                           ▼
┌─────────────────────────────────────────────────────────┐
│                       app.py                             │
│              Streamlit Web Dashboard                     │
│   Live Feed │ Metrics │ Object Table │ Event Log │ Gallery│
└─────────────────────────────────────────────────────────┘
```

### File Structure

```
smart-unattended-detection/
│
├── main.py            # Core pipeline: detect → track → alert
├── app.py             # Streamlit dashboard
├── tracker.py         # DeepSORT wrapper (stable IDs + class recovery)
├── utils.py           # Drawing, geometry, alarm, screenshot helpers
│
├── requirements.txt   # Python dependencies
├── README.md          # This file
│
├── assets/
│   └── alarm.wav      # Alert sound (replace with any WAV/MP3)
│
└── screenshots/       # Auto-created; stores alert evidence JPEGs
```

---

## 🚀 Installation

### Prerequisites
- Python **3.10** or **3.11**
- Webcam **or** a video file for testing
- ~500 MB disk (YOLOv8 weights auto-downloaded on first run)

### Steps

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/smart-unattended-detection.git
cd smart-unattended-detection

# 2. Create and activate a virtual environment (recommended)
python -m venv venv
source venv/bin/activate        # Linux / macOS
# venv\Scripts\activate         # Windows

# 3. Install dependencies
pip install -r requirements.txt

# 4. (Optional) Add an alarm sound
#    Place any .wav file at:  assets/alarm.wav
#    Free sound effects: https://freesound.org
```

> **GPU users:** Uncomment the `torch` lines in `requirements.txt` and install the CUDA build of PyTorch from https://pytorch.org/get-started/locally/ for significantly faster inference.

---

## 🎮 Usage

### Option A — Streamlit Web Dashboard (Recommended)

```bash
streamlit run app.py
```

Open **http://localhost:8501** in your browser.

1. Select your video source (webcam index or video file path) in the sidebar.
2. Adjust alert thresholds and confidence with the sliders.
3. Press **▶ Start**.
4. Watch the live feed, metrics panel, and event log in real time.
5. Screenshots appear automatically in the gallery when CRITICAL alerts fire.

### Option B — Command Line (headless / OpenCV window)

```bash
# Webcam (index 0)
python main.py --source 0

# Video file
python main.py --source path/to/video.mp4

# Headless (no OpenCV window; useful for servers)
python main.py --source 0 --no-display
```

Keyboard shortcuts in the OpenCV window:
| Key | Action |
|-----|--------|
| `q` | Quit |
| `s` | Manual screenshot |

---

## 🎥 Demo

### What to expect

| Scenario | System behaviour |
|---|---|
| Person stands next to their bag | Green bounding box — safe |
| Person walks away slowly | Grace period (< 5 s) — no alert |
| Person gone > 5 seconds | Orange box — WARNING, alarm plays at 50 % |
| Person gone > 10 seconds | Red flashing box — CRITICAL, alarm at 100 %, screenshot saved |
| Person returns | Timer resets — back to safe |

### Test video sources

- **Webcam**: any laptop webcam works; walk away from a bag and back.
- **Sample videos**: search YouTube for "airport surveillance footage" and download with `yt-dlp`.
- **Synthetically generated**: record yourself walking away from a backpack.

---

## ⚙️ Configuration Reference

All defaults are in `main.py → CONFIG`:

```python
CONFIG = {
    "model_path":          "yolov8n.pt",  # swap to yolov8s/m/l/x for more accuracy
    "confidence_threshold": 0.45,
    "owner_link_distance":  200,           # px — max distance to assign owner
    "owner_away_distance":  150,           # px — threshold for "owner gone"
    "warning_time":         5,             # seconds until WARNING
    "critical_time":        10,            # seconds until CRITICAL
    "process_every_n_frames": 2,           # skip frames for performance
    "screenshot_dir":       "screenshots",
    "alarm_path":           "assets/alarm.wav",
}
```

---

## 🔬 Technical Deep-Dive

### Owner Linking Algorithm

```
On first detection of a new bag:
  → Find all currently tracked persons
  → Compute Euclidean distance from bag centre to each person centre
  → If closest person is within owner_link_distance pixels:
      owner_id = that person's track ID
  → Else: owner_id = None (unlinked)

Each frame thereafter:
  → If owner_id is set but owner no longer in frame:
      try to re-link to nearest person
  → Compute current bag-owner distance
  → If distance > owner_away_distance OR owner gone:
      start / advance the unattended timer
  → Else:
      reset timer
```

### Alert State Machine

```
         distance < threshold?
              │
         YES  │  NO
              │
         ─────┼─────────────────────────────────
              │                                  │
          RESET timer                    elapsed < 5s?
          status = SAFE                      │
                                        YES  │  NO
                                             │
                                         SAFE │  elapsed < 10s?
                                             │      │
                                             │  YES │  NO
                                             │      │
                                             │  WARNING │ CRITICAL
```

### Why DeepSORT?

Standard object detectors (including YOLO) are stateless — they output new boxes each frame with no identity continuity. DeepSORT solves this by combining:

- **Kalman filter**: predicts where each object will be next frame
- **Hungarian algorithm**: optimally matches predictions to new detections
- **Appearance CNN**: embeds each crop into a feature vector for re-identification after occlusion

This gives us stable integer IDs that persist across hundreds of frames, which is essential for time-based alerting.

---

## 🔮 Future Improvements

| Idea | Complexity |
|---|---|
| RTSP / IP camera support | Low — just pass RTSP URL as source |
| Multi-camera support | Medium — run detector per stream in parallel threads |
| Web notification / Telegram bot alert | Medium |
| Activity recognition (running, loitering) | High |
| Re-ID across cameras | High |
| Train custom model on airport/station CCTV data | High |
| Database logging (SQLite / PostgreSQL) | Medium |
| Docker container + REST API | Medium |
| Night-vision / thermal camera support | High |

---

## 📄 License

MIT — free to use, modify, and distribute with attribution.

---

## 🙏 Acknowledgements

- [Ultralytics YOLOv8](https://github.com/ultralytics/ultralytics)
- [deep-sort-realtime](https://github.com/levan92/deep_sort_realtime)
- [Streamlit](https://streamlit.io)
- COCO Dataset (pre-trained weights)

---

<div align="center">
  Built for the <strong>AI & Prompt Engineering</strong> Final Project<br>
  <em>"Build something real. Something that works. Something worth showing."</em>
</div>
