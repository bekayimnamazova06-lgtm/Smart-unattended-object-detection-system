"""
Smart Unattended Object Detection System — utils.py
====================================================
Utility functions for:
  - Geometric calculations (center, distance)
  - Frame annotation (bounding boxes, labels, status panel, owner lines)
  - Alarm playback (non-blocking)
  - Screenshot capture

All drawing functions mutate the given frame in-place AND return it,
following OpenCV convention.
"""

import os
import cv2
import time
import logging
import threading
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# ─── Geometry ─────────────────────────────────────────────────────────────────

def calculate_center(bbox: list[int]) -> tuple[int, int]:
    """
    Return the (cx, cy) pixel centre of a bounding box.

    Args:
        bbox: [x1, y1, x2, y2]
    """
    x1, y1, x2, y2 = bbox
    return ((x1 + x2) // 2, (y1 + y2) // 2)


def calculate_distance(p1: tuple, p2: tuple) -> float:
    """
    Euclidean distance between two 2-D points.

    Args:
        p1, p2: (x, y) tuples
    """
    return float(np.linalg.norm(np.array(p1) - np.array(p2)))


# ─── Drawing Helpers ──────────────────────────────────────────────────────────

def _draw_rounded_rect(
    img: np.ndarray,
    pt1: tuple,
    pt2: tuple,
    color: tuple,
    thickness: int = 2,
    radius: int = 10,
):
    """
    Draw a rectangle with rounded corners.
    Falls back to a regular rectangle if radius is too large.
    """
    x1, y1 = pt1
    x2, y2 = pt2
    r = min(radius, (x2 - x1) // 2, (y2 - y1) // 2)
    if r <= 0 or thickness < 0:
        cv2.rectangle(img, pt1, pt2, color, thickness)
        return

    # Four straight edges
    cv2.line(img, (x1 + r, y1), (x2 - r, y1), color, thickness)
    cv2.line(img, (x1 + r, y2), (x2 - r, y2), color, thickness)
    cv2.line(img, (x1, y1 + r), (x1, y2 - r), color, thickness)
    cv2.line(img, (x2, y1 + r), (x2, y2 - r), color, thickness)
    # Four arcs
    cv2.ellipse(img, (x1 + r, y1 + r), (r, r), 180, 0, 90,  color, thickness)
    cv2.ellipse(img, (x2 - r, y1 + r), (r, r), 270, 0, 90,  color, thickness)
    cv2.ellipse(img, (x1 + r, y2 - r), (r, r), 90,  0, 90,  color, thickness)
    cv2.ellipse(img, (x2 - r, y2 - r), (r, r), 0,   0, 90,  color, thickness)


def _put_label(
    img: np.ndarray,
    text: str,
    pos: tuple,
    color: tuple,
    bg_color: tuple = (20, 20, 20),
    font_scale: float = 0.55,
    thickness: int = 1,
):
    """
    Render text with a solid background rectangle for readability.
    """
    font = cv2.FONT_HERSHEY_SIMPLEX
    (tw, th), baseline = cv2.getTextSize(text, font, font_scale, thickness)
    x, y = pos
    # Background pill
    cv2.rectangle(img, (x - 2, y - th - 4), (x + tw + 4, y + baseline), bg_color, -1)
    cv2.putText(img, text, (x, y), font, font_scale, color, thickness, cv2.LINE_AA)


def draw_detections(
    frame: np.ndarray,
    tracked_objects: list[dict],
    object_states: dict,
    person_positions: dict,
    colors: dict,
    class_labels: dict,
) -> np.ndarray:
    """
    Annotate the frame with:
      - Bounding boxes coloured by alert status
      - Track ID and class label
      - Owner-link line between bag and its owner
      - Timer badge showing seconds unattended

    Args:
        frame:           BGR frame to annotate
        tracked_objects: list from tracker.update()
        object_states:   dict { bag_track_id → ObjectState }
        person_positions: dict { person_track_id → (cx, cy) }
        colors:          dict mapping status/role to BGR colour tuples
        class_labels:    dict mapping class_id to string name

    Returns:
        Annotated frame (same object, modified in-place)
    """
    # ── Draw person boxes ─────────────────────────────────────────────────
    for obj in tracked_objects:
        if obj["class_id"] != 0:
            continue
        x1, y1, x2, y2 = obj["bbox"]
        tid = obj["track_id"]
        color = colors["person"]
        _draw_rounded_rect(frame, (x1, y1), (x2, y2), color, thickness=2, radius=8)
        _put_label(frame, f"Person #{tid}", (x1, y1 - 6), color)

    # ── Draw bag boxes + owner lines ──────────────────────────────────────
    for obj in tracked_objects:
        cid = obj["class_id"]
        if cid not in {24, 26, 28}:
            continue

        tid = obj["track_id"]
        x1, y1, x2, y2 = obj["bbox"]
        state = object_states.get(tid)
        status = state.alert_status if state else "safe"
        color = colors.get(status, colors["safe"])

        # Box
        box_thickness = 3 if status == "critical" else 2
        _draw_rounded_rect(frame, (x1, y1), (x2, y2), color, thickness=box_thickness, radius=8)

        # Flashing effect for critical: draw extra outer rectangle
        if status == "critical" and int(time.time() * 2) % 2 == 0:
            cv2.rectangle(frame, (x1 - 4, y1 - 4), (x2 + 4, y2 + 4), color, 2)

        # Label
        label_str = class_labels.get(cid, "object")
        status_emoji = {"safe": "✓", "warning": "!", "critical": "⚠"}.get(status, "")
        _put_label(
            frame,
            f"{status_emoji} {label_str} #{tid}",
            (x1, y1 - 6),
            color,
            bg_color=(0, 0, 0) if status != "critical" else (0, 0, 150),
        )

        # Timer badge (bottom-right of box)
        if state and state.unattended_since is not None:
            elapsed = int(time.time() - state.unattended_since)
            timer_text = f"{elapsed}s unattended"
            _put_label(frame, timer_text, (x1, y2 + 16), color, bg_color=(0, 0, 0))

        # Owner-link dashed line
        if state and state.owner_id is not None:
            owner_center = person_positions.get(state.owner_id)
            if owner_center:
                bag_center = calculate_center([x1, y1, x2, y2])
                _draw_dashed_line(frame, bag_center, owner_center, color, gap=10)

    return frame


def _draw_dashed_line(
    img: np.ndarray,
    pt1: tuple,
    pt2: tuple,
    color: tuple,
    thickness: int = 1,
    gap: int = 8,
):
    """Draw a dashed line between two points."""
    dist = calculate_distance(pt1, pt2)
    if dist < 1:
        return
    steps = int(dist // gap)
    dx = (pt2[0] - pt1[0]) / max(steps, 1)
    dy = (pt2[1] - pt1[1]) / max(steps, 1)
    for i in range(0, steps, 2):
        start = (int(pt1[0] + i * dx), int(pt1[1] + i * dy))
        end = (int(pt1[0] + (i + 1) * dx), int(pt1[1] + (i + 1) * dy))
        cv2.line(img, start, end, color, thickness, cv2.LINE_AA)


def draw_status_panel(
    frame: np.ndarray,
    alert_counts: dict,
    frame_number: int,
) -> np.ndarray:
    """
    Render a semi-transparent HUD panel in the top-left corner showing:
      - System title
      - Current frame number
      - Alert summary counts
    """
    h, w = frame.shape[:2]
    panel_w, panel_h = 260, 110
    overlay = frame.copy()
    cv2.rectangle(overlay, (0, 0), (panel_w, panel_h), (15, 15, 15), -1)
    cv2.addWeighted(overlay, 0.65, frame, 0.35, 0, frame)

    font = cv2.FONT_HERSHEY_SIMPLEX
    cv2.putText(frame, "SURVEILLANCE SYSTEM", (10, 20),
                font, 0.5, (200, 200, 200), 1, cv2.LINE_AA)
    cv2.putText(frame, f"Frame: {frame_number}", (10, 38),
                font, 0.45, (150, 150, 150), 1, cv2.LINE_AA)

    # Safe count
    cv2.putText(frame, f"Safe:     {alert_counts.get('safe', 0)}", (10, 60),
                font, 0.5, (0, 200, 80), 1, cv2.LINE_AA)
    # Warning count
    cv2.putText(frame, f"Warning:  {alert_counts.get('warning', 0)}", (10, 80),
                font, 0.5, (0, 165, 255), 1, cv2.LINE_AA)
    # Critical count
    cv2.putText(frame, f"Critical: {alert_counts.get('critical', 0)}", (10, 100),
                font, 0.5, (0, 0, 220), 1, cv2.LINE_AA)

    # Timestamp
    ts = time.strftime("%H:%M:%S")
    (tw, _), _ = cv2.getTextSize(ts, font, 0.45, 1)
    cv2.putText(frame, ts, (w - tw - 8, 18),
                font, 0.45, (180, 180, 180), 1, cv2.LINE_AA)

    return frame


# ─── Alarm ────────────────────────────────────────────────────────────────────

# Track whether pygame mixer is already initialised
_mixer_ready = False
_alarm_lock = threading.Lock()


def _init_mixer():
    """Attempt to initialise pygame mixer once."""
    global _mixer_ready
    if _mixer_ready:
        return True
    try:
        import pygame
        pygame.mixer.init()
        _mixer_ready = True
        return True
    except Exception as e:
        logger.warning(f"Audio unavailable (pygame error): {e}")
        return False


def play_alarm(alarm_path: str, volume: float = 1.0):
    """
    Play an alarm sound file in a background thread (non-blocking).

    Args:
        alarm_path: path to .wav or .mp3 file
        volume:     0.0 – 1.0
    """
    def _play():
        with _alarm_lock:
            if not os.path.exists(alarm_path):
                logger.warning(f"Alarm file not found: {alarm_path}. Skipping audio.")
                return
            if not _init_mixer():
                return
            try:
                import pygame
                pygame.mixer.music.load(alarm_path)
                pygame.mixer.music.set_volume(max(0.0, min(1.0, volume)))
                pygame.mixer.music.play()
            except Exception as e:
                logger.error(f"Failed to play alarm: {e}")

    t = threading.Thread(target=_play, daemon=True)
    t.start()


# ─── Screenshot ───────────────────────────────────────────────────────────────

def capture_screenshot(frame: np.ndarray, path: str) -> bool:
    """
    Save the current frame as a JPEG screenshot.

    Args:
        frame: BGR numpy array
        path:  file path to save (directories must exist)

    Returns:
        True on success, False on failure
    """
    try:
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        success = cv2.imwrite(path, frame, [cv2.IMWRITE_JPEG_QUALITY, 92])
        if success:
            logger.info(f"Screenshot saved: {path}")
        else:
            logger.error(f"Failed to save screenshot: {path}")
        return success
    except Exception as e:
        logger.error(f"Screenshot error: {e}")
        return False


# ─── Frame Resize Helper ──────────────────────────────────────────────────────

def resize_frame(frame: np.ndarray, max_width: int = 1280) -> np.ndarray:
    """
    Downscale a frame proportionally if it exceeds max_width.
    Useful for limiting inference time on high-res cameras.
    """
    h, w = frame.shape[:2]
    if w <= max_width:
        return frame
    scale = max_width / w
    return cv2.resize(frame, (int(w * scale), int(h * scale)), interpolation=cv2.INTER_AREA)


def bgr_to_rgb(frame: np.ndarray) -> np.ndarray:
    """Convert OpenCV BGR frame to RGB (for display in Streamlit / matplotlib)."""
    return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
