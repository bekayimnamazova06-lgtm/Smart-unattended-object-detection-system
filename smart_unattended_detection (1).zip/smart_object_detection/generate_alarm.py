"""
generate_alarm.py
=================
Generates a 1-second 880 Hz sine wave alarm tone as assets/alarm.wav.
Run this once after cloning if you don't have your own alarm.wav:

    python generate_alarm.py

Requires only the standard library + numpy (already in requirements).
"""

import os
import struct
import math

def generate_beep_wav(
    path: str,
    frequency: float = 880.0,   # Hz  — A5 note, sharp & attention-grabbing
    duration: float = 1.2,       # seconds
    sample_rate: int = 44100,
    amplitude: float = 0.6,      # 0.0 – 1.0  (avoid clipping at 1.0)
    num_beeps: int = 3,
    gap: float = 0.15,           # seconds of silence between beeps
):
    """
    Write a simple multi-beep WAV file without any external audio library.
    Pure stdlib + basic math — guaranteed to work everywhere.
    """
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)

    samples_beep = int(sample_rate * duration)
    samples_gap  = int(sample_rate * gap)

    # Build the full PCM data
    pcm = []
    for _ in range(num_beeps):
        for i in range(samples_beep):
            t = i / sample_rate
            # Sine wave with a short linear fade-in/out to avoid clicks
            fade = min(1.0, i / (sample_rate * 0.01),
                       (samples_beep - i) / (sample_rate * 0.01))
            sample = amplitude * fade * math.sin(2 * math.pi * frequency * t)
            pcm.append(int(sample * 32767))
        pcm.extend([0] * samples_gap)

    num_samples   = len(pcm)
    num_channels  = 1        # mono
    bits_per_sample = 16
    byte_rate     = sample_rate * num_channels * bits_per_sample // 8
    block_align   = num_channels * bits_per_sample // 8
    data_size     = num_samples * block_align
    chunk_size    = 36 + data_size

    with open(path, "wb") as f:
        # RIFF header
        f.write(b"RIFF")
        f.write(struct.pack("<I", chunk_size))
        f.write(b"WAVE")
        # fmt chunk
        f.write(b"fmt ")
        f.write(struct.pack("<I", 16))            # chunk size
        f.write(struct.pack("<H", 1))             # PCM format
        f.write(struct.pack("<H", num_channels))
        f.write(struct.pack("<I", sample_rate))
        f.write(struct.pack("<I", byte_rate))
        f.write(struct.pack("<H", block_align))
        f.write(struct.pack("<H", bits_per_sample))
        # data chunk
        f.write(b"data")
        f.write(struct.pack("<I", data_size))
        for s in pcm:
            f.write(struct.pack("<h", max(-32768, min(32767, s))))

    print(f"✓ Alarm WAV generated: {path}  ({num_samples} samples, {num_beeps} beeps)")


if __name__ == "__main__":
    generate_beep_wav("assets/alarm.wav")
