"""
Smart Unattended Object Detection System — main.py
====================================================
Core processing engine that handles:
  - YOLOv8 object detection
  - DeepSORT tracking
  - Owner-object relationship linking
  - Suspicious / alert logic with time thresholds
  - Screenshot capture & alarm triggering

Author: Generated for AI & Prompt Engineering Final Project
"""

import cv2
import time
import os
import logging
from pathlib import Path
from collections import defaultdict
from typing import Optional

import numpy as np
from ultralytics import YOLO

from tracker import ObjectTracker
from utils import (
    play_alarm,
    capture_screenshot,
    draw_detections,
    calculate_center,
    calculate_distance,
    draw_status_panel,
)

# ─── Logging Configuration ────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)

# ─── Configuration Constants ──────────────────────────────────────────────────
CONFIG = {
    # Model
    "model_path": "yolov8n.pt",          # YOLOv8 nano — fast; swap for yolov8s.pt for accuracy
    "confidence_threshold": 0.45,         # Minimum detection confidence

    # COCO class IDs we care about
    "person_class_id": 0,
    "bag_class_ids": {24, 26, 28},        # backpack=24, handbag=26, suitcase=28

    # Owner-linking: max pixel distance to assign owner on first detection
    "owner_link_distance": 200,

    # Alert thresholds (seconds)
    "warning_time": 5,
    "critical_time": 10,

    # Distance (pixels) beyond which we consider the owner "away"
    "owner_away_distance": 150,

    # Frame processing
    "process_every_n_frames": 2,          # Skip frames for performance

    # Output paths
    "screenshot_dir": "screenshots",
    "alarm_path": "assets/alarm.wav",
}

# Friendly label map for display
CLASS_LABELS = {24: "backpack", 26: "handbag", 28: "suitcase", 0: "person"}

# Alert status colours (BGR)
COLORS = {
    "safe":     (0, 200, 80),    # green
    "warning":  (0, 165, 255),   # orange
    "critical": (0, 0, 220),     # red
    "person":   (255, 200, 0),   # cyan-ish
}


# ─── ObjectState Dataclass ────────────────────────────────────────────────────
class ObjectState:
    """
    Holds the runtime state for a single tracked bag/luggage object.
    """
    __slots__ = [
        "track_id", "class_id", "owner_id",
        "unattended_since", "last_seen_bbox",
        "alert_status", "screenshot_taken",
        "alarm_played",
    ]

    def __init__(self, track_id: int, class_id: int):
        self.track_id: int = track_id
        self.class_id: int = class_id
        self.owner_id: Optional[int] = None       # Track ID of the assigned person
        self.unattended_since: Optional[float] = None  # Epoch timestamp when left alone
        self.last_seen_bbox = None                # (x1, y1, x2, y2)
        self.alert_status: str = "safe"           # "safe" | "warning" | "critical"
        self.screenshot_taken: bool = False
        self.alarm_played: bool = False


# ─── Main Processor Class ─────────────────────────────────────────────────────
class UnattendedObjectDetector:
    """
    Orchestrates the full detection + tracking + alert pipeline.

    Usage:
        detector = UnattendedObjectDetector()
        detector.run(source=0)  # 0 = webcam, or pass a video file path
    """

    def __init__(self, cfg: dict = CONFIG):
        self.cfg = cfg
        self.model = self._load_model()
        self.tracker = ObjectTracker()
        self.object_states: dict[int, ObjectState] = {}   # bag_track_id → ObjectState
        self.person_positions: dict[int, tuple] = {}       # person_track_id → center (x, y)
        self.frame_count = 0
        self.latest_stats = {}   # For external access (e.g., Streamlit)

        # Ensure output directories exist
        Path(self.cfg["screenshot_dir"]).mkdir(parents=True, exist_ok=True)
        logger.info("UnattendedObjectDetector initialised ✓")

    # ── Private helpers ───────────────────────────────────────────────────────

    def _load_model(self) -> YOLO:
        """Load YOLOv8 model. Downloads weights automatically on first run."""
        logger.info(f"Loading YOLO model: {self.cfg['model_path']}")
        model = YOLO(self.cfg["model_path"])
        logger.info("Model loaded ✓")
        return model

    def _detect(self, frame: np.ndarray) -> list[dict]:
        """
        Run YOLOv8 inference on a single frame.

        Returns a list of detection dicts:
            { 'bbox': [x1,y1,x2,y2], 'class_id': int, 'confidence': float }
        """
        results = self.model(frame, verbose=False, conf=self.cfg["confidence_threshold"])[0]
        detections = []
        for box in results.boxes:
            cls_id = int(box.cls[0])
            if cls_id != self.cfg["person_class_id"] and cls_id not in self.cfg["bag_class_ids"]:
                continue
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            detections.append({
                "bbox": [x1, y1, x2, y2],
                "class_id": cls_id,
                "confidence": float(box.conf[0]),
            })
        return detections

    def _find_nearest_person(self, bag_center: tuple) -> Optional[int]:
        """
        Return the track ID of the closest person within link-distance,
        or None if no person is close enough.
        """
        if not self.person_positions:
            return None

        best_id, best_dist = None, float("inf")
        for pid, pcenter in self.person_positions.items():
            dist = calculate_distance(bag_center, pcenter)
            if dist < best_dist:
                best_dist = dist
                best_id = pid

        if best_dist <= self.cfg["owner_link_distance"]:
            return best_id
        return None

    def _update_owner_distance(self, state: ObjectState) -> Optional[float]:
        """
        Compute distance between the bag and its assigned owner.
        Returns None if owner is no longer tracked.
        """
        if state.owner_id is None or state.last_seen_bbox is None:
            return None

        bag_center = calculate_center(state.last_seen_bbox)
        owner_center = self.person_positions.get(state.owner_id)
        if owner_center is None:
            return None  # Owner disappeared from frame

        return calculate_distance(bag_center, owner_center)

    def _evaluate_alert(self, state: ObjectState, dist: Optional[float]) -> str:
        """
        Decide alert level for a bag given current owner distance.

        State machine:
          - Owner present & close  → reset timer → "safe"
          - Owner absent or far    → start / continue timer
            - < warning_time       → "safe"   (grace period)
            - ≥ warning_time       → "warning"
            - ≥ critical_time      → "critical"
        """
        owner_away = (
            dist is None
            or dist > self.cfg["owner_away_distance"]
        )

        if not owner_away:
            # Owner is close — reset everything
            state.unattended_since = None
            state.alert_status = "safe"
            state.screenshot_taken = False
            state.alarm_played = False
            return "safe"

        # Owner is away — start / advance timer
        now = time.time()
        if state.unattended_since is None:
            state.unattended_since = now

        elapsed = now - state.unattended_since

        if elapsed >= self.cfg["critical_time"]:
            return "critical"
        elif elapsed >= self.cfg["warning_time"]:
            return "warning"
        return "safe"

    def _handle_alerts(self, state: ObjectState, frame: np.ndarray):
        """Trigger side-effects (alarm, screenshot) based on alert status."""
        if state.alert_status == "warning" and not state.alarm_played:
            logger.warning(f"[WARNING] Object {state.track_id} unattended!")
            play_alarm(self.cfg["alarm_path"], volume=0.5)
            state.alarm_played = True

        if state.alert_status == "critical" and not state.screenshot_taken:
            logger.error(f"[CRITICAL] Object {state.track_id} critically unattended!")
            play_alarm(self.cfg["alarm_path"], volume=1.0)
            ts = time.strftime("%Y%m%d_%H%M%S")
            path = os.path.join(
                self.cfg["screenshot_dir"],
                f"alert_{state.track_id}_{ts}.jpg"
            )
            capture_screenshot(frame, path)
            state.screenshot_taken = True

    # ── Public API ────────────────────────────────────────────────────────────

    def process_frame(self, frame: np.ndarray) -> tuple[np.ndarray, dict]:
        """
        Process a single video frame end-to-end.

        Returns:
            annotated_frame: frame with bounding boxes and overlays
            stats: dict with summary info for UI consumption
        """
        self.frame_count += 1
        annotated = frame.copy()

        # ── 1. Run YOLO detection ─────────────────────────────────────────
        raw_detections = self._detect(frame)

        # ── 2. Update DeepSORT tracker ────────────────────────────────────
        tracked_objects = self.tracker.update(raw_detections, frame)
        #  tracked_objects: list of { track_id, bbox, class_id }

        # ── 3. Separate persons and bags; update position registry ────────
        current_bag_ids = set()
        self.person_positions = {}  # Refresh each frame

        for obj in tracked_objects:
            tid = obj["track_id"]
            cid = obj["class_id"]
            bbox = obj["bbox"]

            if cid == self.cfg["person_class_id"]:
                self.person_positions[tid] = calculate_center(bbox)
            elif cid in self.cfg["bag_class_ids"]:
                current_bag_ids.add(tid)

                # Register new bags
                if tid not in self.object_states:
                    self.object_states[tid] = ObjectState(tid, cid)
                    logger.info(f"New {CLASS_LABELS[cid]} detected: ID {tid}")

                self.object_states[tid].last_seen_bbox = bbox

        # Remove stale bag states (objects that left the frame)
        gone_ids = set(self.object_states.keys()) - current_bag_ids
        for gid in gone_ids:
            del self.object_states[gid]

        # ── 4. Owner linking + alert evaluation ───────────────────────────
        alert_counts = {"safe": 0, "warning": 0, "critical": 0}

        for tid, state in self.object_states.items():
            bbox = state.last_seen_bbox
            bag_center = calculate_center(bbox)

            # Link owner on first detection or when owner disappears
            if state.owner_id is None or state.owner_id not in self.person_positions:
                state.owner_id = self._find_nearest_person(bag_center)

            dist = self._update_owner_distance(state)
            state.alert_status = self._evaluate_alert(state, dist)
            self._handle_alerts(state, frame)
            alert_counts[state.alert_status] += 1

        # ── 5. Draw all annotations ───────────────────────────────────────
        annotated = draw_detections(
            annotated,
            tracked_objects,
            self.object_states,
            self.person_positions,
            COLORS,
            CLASS_LABELS,
        )
        annotated = draw_status_panel(annotated, alert_counts, self.frame_count)

        # ── 6. Build stats dict for Streamlit ─────────────────────────────
        stats = {
            "frame": self.frame_count,
            "persons": len(self.person_positions),
            "bags": len(self.object_states),
            "warnings": alert_counts["warning"],
            "criticals": alert_counts["critical"],
            "objects": [
                {
                    "id": s.track_id,
                    "label": CLASS_LABELS.get(s.class_id, "object"),
                    "status": s.alert_status,
                    "owner_id": s.owner_id,
                    "unattended_since": s.unattended_since,
                }
                for s in self.object_states.values()
            ],
        }
        self.latest_stats = stats
        return annotated, stats

    def run(self, source=0, display: bool = True):
        """
        Main loop — reads frames from `source` and processes them.

        Args:
            source: webcam index (int) or path to video file (str)
            display: show OpenCV window
        """
        cap = cv2.VideoCapture(source)
        if not cap.isOpened():
            raise RuntimeError(f"Cannot open video source: {source}")

        logger.info(f"Starting detection on source: {source}")
        logger.info("Press 'q' to quit, 's' to take manual screenshot")

        try:
            while True:
                ret, frame = cap.read()
                if not ret:
                    logger.info("End of video stream.")
                    break

                annotated, stats = self.process_frame(frame)

                if display:
                    cv2.imshow("Smart Unattended Object Detection", annotated)
                    key = cv2.waitKey(1) & 0xFF
                    if key == ord("q"):
                        break
                    elif key == ord("s"):
                        ts = time.strftime("%Y%m%d_%H%M%S")
                        capture_screenshot(frame, f"screenshots/manual_{ts}.jpg")
                        logger.info("Manual screenshot saved.")

        finally:
            cap.release()
            if display:
                cv2.destroyAllWindows()
            logger.info("Detection stopped.")


# ─── Entry Point ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Smart Unattended Object Detection")
    parser.add_argument("--source", default=0,
                        help="Video source: 0 for webcam, or path to video file")
    parser.add_argument("--no-display", action="store_true",
                        help="Disable OpenCV window (headless mode)")
    args = parser.parse_args()

    source = int(args.source) if str(args.source).isdigit() else args.source
    detector = UnattendedObjectDetector()
    detector.run(source=source, display=not args.no_display)
